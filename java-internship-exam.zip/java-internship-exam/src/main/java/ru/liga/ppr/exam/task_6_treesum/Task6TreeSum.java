package ru.liga.ppr.exam.task_6_treesum;

public class Task6TreeSum {

    public int treeSum(SimpleTreeNode node) {
        throw new UnsupportedOperationException("Удалите эту строку и напишите реализацию");
    }

}
