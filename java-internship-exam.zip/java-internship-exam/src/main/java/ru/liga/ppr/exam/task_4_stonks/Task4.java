package ru.liga.ppr.exam.task_4_stonks;

import java.util.List;

public class Task4 {

    public boolean checkEquals(List<String> stocks1, List<String> stocks2)  {
      throw new UnsupportedOperationException("Удалите эту строку и напишите реализацию");
    }

}
