package ru.liga.ppr.exam.task_2_emailchecker;

public class Task2 {


	public boolean checkEmail(String address) {
		throw new UnsupportedOperationException("Удалите эту строку и напишите реализацию");
	}

}
