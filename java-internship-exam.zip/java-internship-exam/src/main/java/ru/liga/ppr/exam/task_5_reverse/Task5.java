package ru.liga.ppr.exam.task_5_reverse;

public class Task5 {

    public static Node<String> reverse(
				Node<String> head) {
        throw new UnsupportedOperationException("Удалите эту строку и напишите реализацию");
    }

}
