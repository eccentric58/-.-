package ru.liga.ppr.exam.task_3_inheritance.animals;

public class Human {

}
