package ru.liga.ppr.exam.task_3_inheritance.abstractions;

public abstract class Reptile {

	public abstract boolean canDropTheTail();

}
