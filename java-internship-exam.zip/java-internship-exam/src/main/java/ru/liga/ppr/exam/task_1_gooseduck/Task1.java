package ru.liga.ppr.exam.task_1_gooseduck;

import java.util.List;

public class Task1 {


    public List<String> gooseDuck(int n) {
        throw new UnsupportedOperationException("Удалите эту строку и напишите реализацию");
    }
}
