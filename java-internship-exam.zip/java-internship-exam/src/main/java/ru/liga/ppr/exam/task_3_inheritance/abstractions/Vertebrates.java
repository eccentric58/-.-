package ru.liga.ppr.exam.task_3_inheritance.abstractions;

public interface Vertebrates {

	int countOfVertebra();

}
