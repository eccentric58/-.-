----Goods------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
insert into Goods values('B','1121','Computer');
insert into Goods values('A','1232','Computer');
insert into Goods values('A','1233','Computer');
insert into Goods values('E','1260','Computer');
insert into Goods values('A','1276','MFP');
insert into Goods values('D','1288','MFP');
insert into Goods values('A','1401','MFP');
insert into Goods values('A','1408','MFP');
insert into Goods values('D','1433','MFP');
insert into Goods values('E','1434','MFP');
insert into Goods values('E','2113','Computer');
insert into Goods values('E','2112','Computer');

----Computer------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
insert into Computer values(1,'1232',500,'600');
insert into Computer values(2,'1121',750,'850');
insert into Computer values(3,'1233',500,'600');
insert into Computer values(4,'1121',600,'850');
insert into Computer values(5,'1121',600,'850');
insert into Computer values(6,'1233',750,'950');
insert into Computer values(7,'1232',500,'400');
insert into Computer values(8,'1232',450,'350');
insert into Computer values(9,'1232',450,'350');
insert into Computer values(10,'1260',500,'350');
insert into Computer values(11,'1233',900,'980');
insert into Computer values(12,'1233',800,'970');

----MFP------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
insert into MFP values(1,'1276','400');
insert into MFP values(2,'1433','270');
insert into MFP values(3,'1434','290');
insert into MFP values(4,'1401','150');
insert into MFP values(5,'1408','270');
insert into MFP values(6,'1288','400');