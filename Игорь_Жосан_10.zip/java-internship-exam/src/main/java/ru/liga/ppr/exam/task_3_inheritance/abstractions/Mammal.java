package ru.liga.ppr.exam.task_3_inheritance.abstractions;

public abstract class Mammal implements Vertebrates {

	@Override
	public int countOfVertebra() {
		return 33;
	}

}
