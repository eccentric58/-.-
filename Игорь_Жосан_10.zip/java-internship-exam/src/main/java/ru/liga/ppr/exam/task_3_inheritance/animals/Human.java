package ru.liga.ppr.exam.task_3_inheritance.animals;

import ru.liga.ppr.exam.task_3_inheritance.abstractions.Mammal;

public class Human extends Mammal {
    @Override
    public int countOfVertebra() {
        return 33;
    }
}
